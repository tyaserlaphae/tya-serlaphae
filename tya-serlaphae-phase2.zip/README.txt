Tya Serlaphae — Phase 2 (ivory + eye icon + search)
Generated 2025-10-06T02:52:45.230993Z

Files:
- index.html (homepage with fixed centered search "daydream" + eye circle linking to aesthetics.html)
- aesthetics.html (placeholder 10-category list)
- styles.css (ivory theme, Italianno cursive, white glow)
- script.js (minimal)
- unnamed.jpg (your eye image)

Deploy:
1) Upload/replace these files in your GitHub repo.
2) Vercel redeploys automatically.
3) Visit https://tya-serlaphae-7b95.vercel.app
